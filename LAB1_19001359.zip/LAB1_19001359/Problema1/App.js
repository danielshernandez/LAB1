import { StatusBar } from 'expo-status-bar';
import React, {Component} from 'react';
import { StyleSheet, Text, View, TextInput, Button, ImageBackground } from 'react-native';

const image = { uri: "https://i.pinimg.com/236x/6e/6c/a0/6e6ca0b10832cc9899f976cbc13be6a2.jpg" };

export default class App extends React.Component {

  state = {
 celsius: null,
 fahrenheit: null,  
 celsius1: null,
 fahrenheit1: null,   
 }
 updateState = () => this.setState ( {

  fahrenheit: (this.state.celsius * 9/5) + 32,
 
   })  
   updateState1 = () => this.setState ( {
  
  
  celsius1: (this.state.fahrenheit1 - 32) * 5 / 9
    })  
   render() {
  const  { celsius, fahrenheit, celsius1, fahrenheit1 } = this.state

  return (
    <View style={styles.container}>
      <ImageBackground source={image} style={styles.image}>
    
        <Text style={styles.titulo}>Conversión de Grados Centigrados y Grados Farenheith </Text> 

        <Text style={styles.textos}>Grados Centigrados: </Text>
        <TextInput
          style={styles.inputStyle}
          value={this.state.celsius}
          placeholder="Ingrese los grados en Centigrados"
          onChangeText={ (celsius) => this.setState({ celsius })}
        />

        <Text style={styles.textos}>Grados Farenheith:</Text>

        <TextInput
          style={styles.inputStyle}
          value={this.state.fahrenheit1}
          placeholder="Ingrese los grados en Farenheith"
          onChangeText={ (fahrenheit1) => this.setState({fahrenheit1})}
        />

        <View style={[{ width: '85%', flexDirection: 'row', marginTop: 20}]}> 
          <Text style={styles.resultados}> Resultado: {fahrenheit}</Text>

          <Text style={styles.resultados2}> Resultado: {celsius1} </Text>
        </View>

        <View style={[{ width: '85%', flexDirection: 'row'}]}> 
          <View style={[{ width: '40%', height: 40 , backgroundColor: "#7b7b7b", marginTop: 50, marginBottom: 30, marginRight: '20%'}]}>
              <Button
                title= 'Centigrados a Farenheith'
                color="#7b7b7b"
                onPress = { () => { this.updateState()}}
              />
          </View>

          <View style={[{ width: "40%", height: 40 , backgroundColor: "#7b7b7b", marginTop: 50, marginBottom: 30}]}>
              <Button
                title= 'Farenheith a Centigrados'
                color="#7b7b7b"
                onPress = { () => {this.updateState1()}}
              />
          </View>
        </View>

        
      </ImageBackground>

      <StatusBar style="auto" />
    </View>
  );
}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },

  inputStyle:{
    height: 40,
    backgroundColor: '#eee',
    borderBottomWidth: 2,
    borderBottomColor: '#ccc',
    width: '70%',
    paddingLeft: 10,
    marginBottom: 50,
    marginTop: 10,
    
  },
  boton:{
    paddingBottom: 20,
    paddingTop: 10,
  },

  titulo:{
    fontWeight: "bold",
    fontSize: 40,
    fontFamily: 'Cooper Black',
    marginBottom: 100,
    marginTop: 50,
    width: "90%",
    textAlign: 'center',
    color: "white"
  },

  textos:{
    fontWeight: "bold",
    fontFamily:'Lucida Sans',
    fontSize: 20,
    marginBottom: 20,
    marginTop: 15
  },

  resultados:{
    width: '50%',
    marginRight:"10%",
    fontWeight: 'bold',
    fontFamily: 'Georgia Pro Black',
    fontSize: 20
    
  },

  resultados2:{
    width: '50%',
    fontWeight: 'bold',
    paddingLeft: '5%',
    fontFamily: 'Georgia Pro Black',
    fontSize: 20
    
  },
  
  image: {
    alignItems: 'center',
    justifyContent: 'center',
    resizeMode: "cover",
    
  },
});
