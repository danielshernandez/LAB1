import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View, Image, TextInput, CheckBox, Button } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>

      <Image
          style={styles.image}
          source={require('./assets/logo.png')}
      />

      <TextInput
        style={styles.inputStyle}
        placeholder="Usuario"
      />

      <TextInput
        style={styles.inputStyle2}
        placeholder="Contraseña"
      />

      <Text
        style={styles.textinput1}
      >
        ¿Olvidó su contraseña?
      </Text>

      <View style={styles.checkboxContainer}>
        <CheckBox
          style={styles.checkbox}
        />
        <Text style={styles.text2}><Text style={styles.text1}> BAC </Text>Token</Text>
      </View>

      <View style={[{ width: "85%", height: 40 , backgroundColor: "#7b7b7b", marginTop: 80, marginBottom: 30 }]}>
          <Button
            title= 'Ingresar'
            color="#7b7b7b"
          />
        </View>

       <Text
        style={styles.text3}
      >
        ¿Primera vez que ingresa? <Text style={styles.text4}>Crea Usuario </Text>
      </Text>


      <Text
        style={styles.textinput2}
      >
        Tipo de Cambio >
      </Text>
      

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#eee'
  },

  image:{
    height: 150,
    width: 150,
    marginBottom:20
  },

  inputStyle:{
    height: 40,
    backgroundColor: '#eee',
    borderBottomWidth: 2,
    borderBottomColor: '#ccc',
    width: '85%',
    paddingLeft: 10,
    marginBottom: 30,
    marginTop: 10
  },

  inputStyle2:{
    height: 40,
    backgroundColor: '#eee',
    borderBottomWidth: 2,
    borderBottomColor: '#ccc',
    width: '85%',
    paddingLeft: 10,
    marginBottom: 15,
    marginTop: 10
  },

  textinput1:{
    width: "85%",
    textAlign: 'right',
    color: '#14adcc',
    fontWeight: 'bold',
    fontSize: '4',
    marginBottom: 30,
  },

  textinput2:{
    width: "85%",
    textAlign: 'right',
    color: '#14adcc',
    fontWeight: 'bold',
    fontSize: '4',
    marginBottom: 20,
    marginTop: 35
  },

  checkboxContainer: {
    flexDirection: "row",
    marginBottom: 20,
    width: '83%'
    
    
  },
  checkbox: {
   
    
    
  },
 

  text1:{
    color: 'red',
    fontWeight: 'bold'
  },

  text2:{
    color: '#7b7b7b',
    fontWeight: 'bold'
  },

  text3:{
    color: '#7b7b7b',
  },

  text4:{
    color: '#14adcc',
    fontWeight: 'bold'
  },

});
